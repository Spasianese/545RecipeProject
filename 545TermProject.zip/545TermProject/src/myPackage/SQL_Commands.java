package myPackage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;

public class SQL_Commands {
    
    Connection conn = null;
    OraclePreparedStatement pst = null;
    OracleResultSet rs = null;
    
     public Connection setupConnection()
    {
        String jdbcDriver = "oracle.jdbc.driver.OracleDriver";
        String jdbcUrl = "jdbc:oracle:thin:@//CSITOracle.eku.edu:1521/CSCPDB";  // URL for the database
        String username = "GaonaI545";
        String password = "Pa$$2768";
        
        try
        {
            // Load jdbc driver.            
            Class.forName(jdbcDriver);
            
            // Connect to the Oracle database
            Connection conn = DriverManager.getConnection(jdbcUrl, username, password);
            System.out.println("Connection Successfully Set Up");
            return conn;
        }
        catch (ClassNotFoundException | SQLException e)
        {
            System.out.println("struggling");
        }
        return null;
    }
     
    public void close(Connection conn) 
    {
        if(conn != null) 
        {
            try
            {
                conn.close();
            }
            catch(SQLException whatever)
            {}
        }
    }

    public void close(OraclePreparedStatement st)
    {
        if(st != null)
        {
            try
            {
                st.close();
            }
            catch(SQLException whatever)
            {}
        }
    }

    public void close(OracleResultSet rs)
    {
        if(rs != null)
        {
            try
            {
                rs.close();
            }
            catch(SQLException whatever)
            {}
        }
    }
}
